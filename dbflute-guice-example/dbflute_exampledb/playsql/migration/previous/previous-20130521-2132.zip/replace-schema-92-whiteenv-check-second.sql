-- #df:checkEnv(ut)#

-- This is check for environmentType.
-- And the check test depends that the type is 'ut'.

drop table WHITE_CHECK_ENV;