-- #df:checkEnv(noway)#

-- #df:begin#
select * from NOEXIST
-- #df:end#
