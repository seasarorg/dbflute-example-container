-- #df:checkEnv(noway)#

select * from NOEXIST
