#!/bin/bash

export ANT_OPTS=-Xmx512m

export DBFLUTE_HOME=../mydbflute/dbflute-1.0.5G

export MY_PROJECT_NAME=dfclient

export MY_PROPERTIES_PATH=build.properties
